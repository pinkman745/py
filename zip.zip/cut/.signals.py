import numpy as np
import matplotlib.pyplot as plt
f = 10
t = np.arange(0, 1, 0.01)
s = np.sin(2*np.pi*f*t)
plt.plot(t,s)
plt.title('Sine wave')
plt.xlabel('Time')
plt.ylabel('Amplitude')
plt.grid(True, which='both')
plt.axhline(y=0, color='k')
plt.show()